package com.futuroai

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.content.*
import android.view.*
import android.widget.*
import kotlin.random.Random

class MainActivity : Activity() {
    lateinit var root: LinearLayout
    lateinit var question: EditText
    lateinit var result: TextView
    lateinit var score: TextView
    var predictions = 0
    var hits = 0

    fun tv(text:String, size:Float=18f): TextView = TextView(this).apply {
        this.text=text; textSize=size; setTextColor(Color.WHITE); setPadding(20,18,20,18)
    }
    fun button(text:String, action:()->Unit) = Button(this).apply {
        this.text=text; setOnClickListener{action()}; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(91,61,190))
    }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        showHome()
    }

    fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(24,35,24,24)
            setBackgroundColor(Color.rgb(9,11,24))
        }
    }

    fun showHome() {
        root=base()
        root.addView(tv("🔮  FUTURO AI",30f))
        root.addView(tv("Explora lo que podría venir.",17f))
        root.addView(tv("Predice. Comprueba. Comparte.",14f))
        root.addView(tv("\n✨ DESAFÍA A FUTURO AI",22f))
        question=EditText(this).apply {
            hint="Escribe tu pregunta…"; setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE); setSingleLine(false); minLines=3
            setBackgroundColor(Color.rgb(28,31,52)); setPadding(18,18,18,18)
        }
        root.addView(question, LinearLayout.LayoutParams(-1,140))
        root.addView(button("🔮 CREAR PREDICCIÓN"){makePrediction()},
            LinearLayout.LayoutParams(-1,60).apply{setMargins(0,18,0,10)})
        score=tv("🏆 FUTURO AI SCORE: ${if(predictions==0) "--" else "${hits*100/predictions}%"}",20f)
        root.addView(score)
        setContentView(root)
    }

    fun makePrediction() {
        val q=question.text.toString().trim()
        if(q.isEmpty()){ Toast.makeText(this,"Escribe una pregunta primero.",Toast.LENGTH_SHORT).show(); return }
        predictions++
        val options=listOf(
            "Hay señales de un cambio positivo si aprovechas una oportunidad que aparezca.",
            "Podrías recibir información inesperada; tómate un momento antes de decidir.",
            "Un pequeño esfuerzo constante podría producir un resultado mejor de lo esperado.",
            "Es posible que algo que estabas esperando avance, aunque no exactamente como imaginabas."
        )
        val confidence=60+Random.nextInt(31)
        result=tv("🔮 ESCENARIO PROBABLE\n\nPregunta:\n$q\n\n${options.random()}\n\n⭐ Coincidencia estimada: $confidence%\n\n⚠️ Esto es un escenario generado por IA para entretenimiento y reflexión; no es una predicción garantizada.",18f)
        root=base()
        root.addView(tv("🔮 RESULTADO FUTURO AI",26f))
        root.addView(result)
        root.addView(button("📅 GUARDAR Y COMPROBAR DESPUÉS"){ 
            Toast.makeText(this,"Predicción guardada. Vuelve después para comprobarla.",Toast.LENGTH_LONG).show()
        })
        root.addView(button("📲 COMPARTIR RESULTADO"){
            val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,result.text.toString()+"\n— FUTURO AI")}
            startActivity(Intent.createChooser(i,"Compartir con…"))
        })
        root.addView(button("🏆 ¿ACERTÓ?"){
            AlertDialog.Builder(this).setTitle("¿FUTURO AI acertó?")
                .setItems(arrayOf("✅ Sí","🟡 Más o menos","🔴 No")){_,which->
                    if(which<2) hits++
                    showHome()
                }.show()
        })
        root.addView(button("← Volver al inicio"){showHome()})
        setContentView(root)
    }
}
